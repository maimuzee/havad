
package javagame;
import org.lwjgl.input.Mouse;
import org.newdawn.slick.*;
import org.newdawn.slick.state.*;
//import org.lwjgl.input.Mouse;
public class Menu extends BasicGameState{
	
	Image download;
	Image stop;
	Image setting;
	Image exit;
	Image gz;
	
	public String mouse="no input yet?";
	
	
	
	public Menu(int state){
		
    }

	
	
	
	public void init(GameContainer gc,StateBasedGame sbg) throws SlickException{
		download=new Image("res/right.png");
		stop=new Image("res/help_black.png");
		setting=new Image("res/cog-icon-2-48x48.png");
		exit=new Image("res/button_cancel.png");
		
		gz=new Image("res/Great-Zimbabwe-BW-650px.jpg");



		//download=new Image("res/player_play_256.png");

			}



	
	public void render(GameContainer gc,StateBasedGame sbg,Graphics g) throws SlickException{
		
		gz.draw(0,0,2.6f);
		g.drawImage(download,500,100);
		g.drawImage(stop,500,300);
		g.drawImage(setting,500,500);
		g.drawImage(exit,500,700);
		

		
		//g.drawString("MAIN_MENU", 310,110);
		g.drawString("PLAY",400,150);
		g.drawString("OPTIONS",400,550);
		g.drawString("HELP",400,350);
		g.drawString("EXIT",400,730);
		
		//g.drawOval(250, 100, 200,50);
		//g.drawOval(250, 290, 150,50);
		//g.drawOval(250, 390, 150,50);
		//g.drawOval(250, 490, 150,50);
		//g.drawOval(250, 590, 150,50);
	
		
		
	//	Input input=gc.getInput();
		int xpos=Mouse.getX();
		int ypos=Mouse.getY();
		mouse="Mouse position x:"+ xpos +" y:" +ypos;
			
			

		
			
		
		
		 
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
}
	public void update(GameContainer gc,StateBasedGame sbg,int delta) throws SlickException{
			


		Input input=gc.getInput();
		int xpos=Mouse.getX();
		int ypos=Mouse.getY();
		mouse="Mouse position x:"+ xpos +" y:" +ypos;
		
		if((xpos>600 && xpos<650) &&(ypos>100 && ypos<180)){
			
			if (input.isKeyDown(Input.KEY_ENTER)){
			sbg.enterState(4);
			
			
			
	}}
		
		
		
		
		
	if((xpos>500 && xpos<600) &&(ypos>400 && ypos<500)){
		
		if (input.isKeyDown(Input.KEY_ENTER)){
		sbg.enterState(3);
		
}}

if((xpos>500 && xpos<600) &&(ypos>20 && ypos<150)){
	
	if (input.isKeyDown(Input.KEY_ENTER)){
	sbg.enterState(4);
	
}}
if((xpos>500 && xpos<600) &&(ypos>220 && ypos<280)){
	
	if (input.isKeyDown(Input.KEY_ENTER)){
	sbg.enterState(2);
	}}
	
	
	
	if((xpos>500 && xpos<600) &&(ypos>610 && ypos<690)){
		
		if (input.isKeyDown(Input.KEY_ENTER)){
		sbg.enterState(0);
		}}
		
		

	}

	public int getID(){
		return 1;
	}}	
