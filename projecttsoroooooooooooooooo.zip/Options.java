

package javagame;
import org.lwjgl.input.Mouse;
import org.newdawn.slick.*;
import org.newdawn.slick.state.*;





public class Options extends BasicGameState{
	
	Image level;
	Image gz;
	Image sound;
	Image menu;
	public String mouse="no input yet?";
	

	
	
	
	public Options(int state){
		
    }

	
	
	
	public void init(GameContainer gc,StateBasedGame sbg) throws SlickException{
	level=new Image("res/ihandy_level.png");
	gz=new Image("res/Great-Zimbabwe-BW-650px.jpg");
	sound=new Image("res/sound_settings.png");
	menu=new Image("res/menu_pull_up.png");
	}



	public void render(GameContainer gc,StateBasedGame sbg,Graphics g) throws SlickException{
		
	//	Input input=gc.getInput();
		int xpos=Mouse.getX();
		int ypos=Mouse.getY();
		mouse="Mouse position x:"+ xpos +" y:" +ypos;
		
		gz.draw(0,0,2.6f);
		g.drawImage(level,600,200);
		g.drawImage(sound,600,400);
		g.drawImage(menu,600,600);
		
		g.drawString("LEVEL",450,220);
		g.drawString("SOUND",450,420);
		g.drawString("MENU",450,620);
	


}
	public void update(GameContainer gc,StateBasedGame sbg,int delta) throws SlickException{
			
		Input input=gc.getInput();
		int xpos=Mouse.getX();
		int ypos=Mouse.getY();
		mouse="Mouse position x:"+ xpos +" y:" +ypos;


		if((xpos>600 && xpos<700) &&(ypos>100 && ypos<180)){
			
			if (input.isKeyDown(Input.KEY_ENTER)){
			sbg.enterState(1);
			}}
		if((xpos>300 && xpos<400) &&(ypos>220 && ypos<280)){
			
			//if (input.isKeyDown(Input.KEY_9)){
			//sbg.enterState(2);
			}
		if((xpos>300 && xpos<400) &&(ypos>220 && ypos<280)){
			
			//if (input.isKeyDown(Input.KEY_9)){
			//sbg.enterState(2);
			}

}
	public int getID(){
		return 2;
	}}	
