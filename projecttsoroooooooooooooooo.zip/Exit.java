
package javagame;
import org.lwjgl.input.Mouse;
import org.newdawn.slick.*;
import org.newdawn.slick.state.*;





public class Exit extends BasicGameState{
	
	Image yes;
	Image no;
	Image gz;

	public String mouse="no input yet?";

	
	
	public Exit(int state){
		
    }

	
	
	
	public void init(GameContainer gc,StateBasedGame sbg) throws SlickException{
	yes=new Image("res/red_ok.png");
	no=new Image("res/cancel.png");
	gz=new Image("res/Great-Zimbabwe-BW-650px.jpg");
	
	}



	public void render(GameContainer gc,StateBasedGame sbg,Graphics g) throws SlickException{
		//Input input=gc.getInput();
		int xpos=Mouse.getX();
		int ypos=Mouse.getY();
		mouse="Mouse position x:"+ xpos +" y:" +ypos;
	
	gz.draw(0,0,2.6f);
	g.drawImage(yes,300,550);	
	g.drawImage(no,900,550);	
	g.drawString("ARE YOU SURE YOU WANT TO EXIT.?", 550, 300);
	g.drawString("YES",310,630);
	g.drawString("CANCEL",900,630);
}
	public void update(GameContainer gc,StateBasedGame sbg,int delta) throws SlickException{
			

		Input input=gc.getInput();
		int xpos=Mouse.getX();
		int ypos=Mouse.getY();
		mouse="Mouse position x:"+ xpos +" y:" +ypos;
			
		if((xpos>300 && xpos<340) &&(ypos>190 && ypos<250)){
			
			if (input.isKeyDown(Input.KEY_ENTER)){
			sbg.enterState(-1);
	
		}}
		if((xpos>870 && xpos<940) &&(ypos>180 && ypos<250)){
			
			if (input.isKeyDown(Input.KEY_ENTER)){
			sbg.enterState(1);
			}}
			
			

}
	public int getID(){
		return 4;
	}}	
