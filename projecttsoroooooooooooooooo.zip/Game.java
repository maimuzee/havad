
package javagame;

import org.newdawn.slick.*;
//import org.newdawn.slick.geom.Vector2f;
import org.newdawn.slick.state.*;


public class Game extends StateBasedGame {
	
	public static final String gamename="TSORO";
	public static final int play=0;
	public static final int menu=1;
	public static final int options=2;
	public static final int help=3;
	public static final int exit=4;
	public static final int first=5;
	//public static final int movements=5;
	public Game(String gamename){
		super(gamename);
		this.addState(new Play(play));
		this.addState(new Menu(menu));
		this.addState(new Options(options));
		this.addState(new Help(help));
		
		this.addState(new Exit(exit));
		this.addState(new First(first));


		


	}
	
	
	public void initStatesList(GameContainer gc) throws SlickException{
		this.getState(play).init(gc,this);
		this.getState(menu).init(gc,this);
		this.getState(options).init(gc,this);
		this.getState(help).init(gc,this);
		this.getState(exit).init(gc,this);
		this.getState(first).init(gc,this);

		
		this.enterState(play);
		
		this.enterState(options);
		this.enterState(help);
		this.enterState(exit);
		this.enterState(menu);
		this.enterState(first);
		
	}
	

	public static void main(String[] args){
	
		AppGameContainer appgc;
		
		
		try{
			appgc=new AppGameContainer(new Game(gamename));
			appgc.setDisplayMode(1600,800,false);
			appgc.start();
			
		}catch(SlickException e){
			e.printStackTrace();
		}
	}}
	
	
	
	
	
	
	