
package javagame;
import java.lang.Thread;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.awt.image.*;
import java.io.*;

import org.newdawn.slick.*;
import org.newdawn.slick.geom.Vector2f;
import org.newdawn.slick.state.*;
import org.lwjgl.input.Mouse;






@SuppressWarnings("unused")
public class Play extends BasicGameState {
	
	
		public  int counter;
 
	int j=0;
	int i;
	int x,y;
	int count,mike,terry,havad,alpha,tango,chali,delta,oxfod,erau,cambi,stan,millij,loyd,hit,kuda,nasa,tafa,mit,geek;
	int variable1;
	boolean drawImage=true;
	public String mouse="no input yet?";
	public Graphics g;
	Image pot[]=new Image[16];
	Image fistdown;
	Image menu;
	Image exit;
	Image back;
	Image gz;

	float fistdownx=210,fistdowny=370;
	//float shiftx=fistdownx+50;
	//float shifty=fistdowny+50;
	
		
	Animation left,right,up,down;		
		
		
		
		
		
		
	
	 float xpos0[]={410,410,510,610,710,710,610,510,-1};
	float ypos0[]={165,215,215,215,215,165,165,165,-1};
	
	float xpos1[]={510,410,410,510,610,710,710,610,510,-1};
	float ypos1[]={165,165,215,215,215,215,165,165,165,-1};
	
	float xpos2[]={610,510,410,410,510,610,710,710,610,-1};
	 float ypos2[]={165,165,165,215,215,215,215,165,165,-1};
	
	float xpos3[]={710,610,510,410,410,510,610,710,710-1};
	float ypos3[]={165,165,165,165,215,215,215,215,165-1};
	
	float xpos4[]={410,510,610,710,710,610,710,610,610,-1};
	float ypos4[]={215,215,215,215,165,165,165,165,215,-1};
	
	float xpos5[]={510,610,710,710,610,510,410,410,510,-1};
	float ypos5[]={215,215,215,165,165,165,165,215,215,-1};
	
	float xpos6[]={610,710,710,610,510,410,410,510,610,-1};
	float ypos6[]={215,215,165,165,165,165,215,215,215,-1};
	
	float xpos7[]={710,710,610,510,410,410,510,610,710,-1};
	float ypos7[]={215,165,165,165,165,215,215,215,215,-1};
	
	
	
	
	
	
	float xpos8[]={407,407,507,607,707,707,607,507,407,-1};
	float ypos8[]={310,371,371,371,371,310,310,310,310,-1};
	
	float xpos9[]={507,407,407,507,607,707,707,607,607,-1};
	float ypos9[]={310,310,371,371,371,371,310,310,310,-1};
	
	float xpos10[]={607,507,407,407,507,607,707,707,607,-1};
	float ypos10[]={310,310,310,371,371,371,371,310,310,-1};
	
	float xpos11[]={707,607,507,407,407,507,607,707,707,-1};
	float ypos11[]={310,310,310,310,371,371,371,371,310,-1};
	
	float xpos12[]={407,507,607,707,707,607,507,407,407,-1};
	float ypos12[]={371,371,371,371,310,310,310,310,371,-1};
	
	float xpos13[]={507,607,707,707,607,507,407,407,507,-1};
	float ypos13[]={371,371,371,310,310,310,310,371,371,-1};
	
	float xpos14[]={607,707,707,607,507,407,407,507,607,-1};
	float ypos14[]={371,371,310,310,310,310,371,371,371,-1};
	
	float xpos15[]={707,707,607,507,407,407,507,607,707,-1};
	float ypos15[]={371,310,310,310,310,371,371,371,371,-1};
	public
	Color Color;

	
	
	
			
	Runnable r=new Runnable(){
		public void run(){
			try {
				Sleep(2000);
				loop12();
				loop13();
			} catch (SlickException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			
			}};
		
	
	
	
	public void loop11() throws SlickException{
		if(kuda==11){

		pot[11]=new Image("res/pot0.png");
		pot[10]=new Image("res/pot4.png");
		pot[9]=new Image("res/pot4.png");
		pot[8]=new Image("res/pot3.png");
		
		}
		if(counter==10){
			pot[10]=new Image("res/pot0.png");
			pot[9]=new Image("res/pot4.png");
			pot[8]=new Image("res/pot4.png");
			pot[12]=new Image("res/pot0.png");
			pot[13]=new Image("res/pot4.png");
			pot[14]=new Image("res/pot4.png");
			pot[15]=new Image("res/pot4.png");
			pot[11]=new Image("res/pot4.png");
			}
			else if (counter==9){
				
				
						pot[8]=new Image("res/pot0.png");
						pot[12]=new Image("res/pot5.png");
						pot[13]=new Image("res/pot1.png");
						pot[14]=new Image("res/pot5.png");
						pot[15]=new Image("res/pot5.png");
						pot[11]=new Image("res/pot5.png");
						pot[10]=new Image("res/pot5.png");
						pot[9]=new Image("res/pot1.png");
				
				
				
				
				
				
				}
			
			else if (counter==4){
				pot[8]=new Image("res/pot0.png");
				pot[12]=new Image("res/pot5.png");
				pot[13]=new Image("res/pot1.png");
				pot[14]=new Image("res/pot5.png");
				pot[15]=new Image("res/pot5.png");
				pot[11]=new Image("res/pot5.png");
				pot[10]=new Image("res/pot5.png");
				pot[9]=new Image("res/pot1.png");
		

			}
			else if (counter==5){
				pot[8]=new Image("res/pot0.png");
				pot[12]=new Image("res/pot5.png");
				pot[13]=new Image("res/pot1.png");
				pot[14]=new Image("res/pot5.png");
				pot[15]=new Image("res/pot5.png");
				pot[11]=new Image("res/pot5.png");
				pot[10]=new Image("res/pot5.png");
				pot[9]=new Image("res/pot1.png");
		

			}
			else if (counter==6){
				pot[8]=new Image("res/pot0.png");
				pot[12]=new Image("res/pot5.png");
				pot[13]=new Image("res/pot1.png");
				pot[14]=new Image("res/pot5.png");
				pot[15]=new Image("res/pot5.png");
				pot[11]=new Image("res/pot5.png");
				pot[10]=new Image("res/pot5.png");
				pot[9]=new Image("res/pot1.png");
		

			}
			else if (counter==7){
				pot[8]=new Image("res/pot0.png");
				pot[12]=new Image("res/pot5.png");
				pot[13]=new Image("res/pot1.png");
				pot[14]=new Image("res/pot5.png");
				pot[15]=new Image("res/pot5.png");
				pot[11]=new Image("res/pot5.png");
				pot[10]=new Image("res/pot5.png");
				pot[9]=new Image("res/pot1.png");
		

			}
			else if (counter==8){
				pot[8]=new Image("res/pot0.png");
				pot[12]=new Image("res/pot5.png");
				pot[13]=new Image("res/pot1.png");
				pot[14]=new Image("res/pot5.png");
				pot[15]=new Image("res/pot5.png");
				pot[11]=new Image("res/pot5.png");
				pot[10]=new Image("res/pot5.png");
				pot[9]=new Image("res/pot1.png");
		

			}
			else if (counter==8){
				pot[8]=new Image("res/pot0.png");
				pot[12]=new Image("res/pot5.png");
				pot[13]=new Image("res/pot1.png");
				pot[14]=new Image("res/pot5.png");
				pot[15]=new Image("res/pot5.png");
				pot[11]=new Image("res/pot5.png");
				pot[10]=new Image("res/pot5.png");
				pot[9]=new Image("res/pot1.png");
		

			}
			else if (counter==9){
				pot[8]=new Image("res/pot0.png");
				pot[12]=new Image("res/pot5.png");
				pot[13]=new Image("res/pot1.png");
				pot[14]=new Image("res/pot5.png");
				pot[15]=new Image("res/pot5.png");
				pot[11]=new Image("res/pot5.png");
				pot[10]=new Image("res/pot5.png");
				pot[9]=new Image("res/pot1.png");
		
		
			}

		
			} 
	
	public void loop10() throws SlickException{
		if(counter==1){
		
		pot[10]=new Image("res/pot0.png");
		pot[9]=new Image("res/pot4.png");
		pot[8]=new Image("res/pot4.png");
		pot[12]=new Image("res/pot0.png");
		pot[13]=new Image("res/pot4.png");
		pot[14]=new Image("res/pot4.png");
		pot[15]=new Image("res/pot4.png");
		pot[11]=new Image("res/pot4.png");
		
		}
			else if(mike==2){}
			else if(mike==2){}
			else if(mike==2){}
			else if(mike==2){}
			else if(mike==2){}
			else if(mike==2){}
			else if(mike==2){}
			
			
		else if (counter==2){
			
					if(mike==9){
					pot[8]=new Image("res/pot5.png");
					pot[12]=new Image("res/pot1.png");
					pot[13]=new Image("res/pot5.png");
					pot[14]=new Image("res/pot0.png");
					pot[15]=new Image("res/pot5.png");
					pot[11]=new Image("res/pot5.png");
					pot[10]=new Image("res/pot1.png");
					pot[9]=new Image("res/pot1.png");
			
					}
			
					else if(mike==2){}
					else if(mike==2){}
					else if(mike==2){}
					else if(mike==2){}
					else if(mike==2){}
					else if(mike==2){}
					else if(mike==2){}
				
			
			
			}
		
		else if (counter==3){
			if(mike==1){
			pot[8]=new Image("res/pot0.png");
			pot[12]=new Image("res/pot5.png");
			pot[13]=new Image("res/pot1.png");
			pot[14]=new Image("res/pot5.png");
			pot[15]=new Image("res/pot5.png");
			pot[11]=new Image("res/pot5.png");
			pot[10]=new Image("res/pot5.png");
			pot[9]=new Image("res/pot1.png");}
			else if(mike==2){}
			else if(mike==2){}
			else if(mike==2){}
			else if(mike==2){}
			else if(mike==2){}
			else if(mike==2){}
			else if(mike==2){}
	

		}
		else if (counter==4){
			if(mike==1){
			
			pot[8]=new Image("res/pot0.png");
			pot[12]=new Image("res/pot5.png");
			pot[13]=new Image("res/pot1.png");
			pot[14]=new Image("res/pot5.png");
			pot[15]=new Image("res/pot5.png");
			pot[11]=new Image("res/pot5.png");
			pot[10]=new Image("res/pot5.png");
			pot[9]=new Image("res/pot1.png");}
			else if(mike==2){}
			else if(mike==2){}
			else if(mike==2){}
			else if(mike==2){}
			else if(mike==2){}
			else if(mike==2){}
			else if(mike==2){}
	

		}
		else if (counter==5){
			pot[8]=new Image("res/pot0.png");
			pot[12]=new Image("res/pot5.png");
			pot[13]=new Image("res/pot1.png");
			pot[14]=new Image("res/pot5.png");
			pot[15]=new Image("res/pot5.png");
			pot[11]=new Image("res/pot5.png");
			pot[10]=new Image("res/pot5.png");
			pot[9]=new Image("res/pot1.png");
	

		}
		else if (counter==6){
			pot[8]=new Image("res/pot0.png");
			pot[12]=new Image("res/pot5.png");
			pot[13]=new Image("res/pot1.png");
			pot[14]=new Image("res/pot5.png");
			pot[15]=new Image("res/pot5.png");
			pot[11]=new Image("res/pot5.png");
			pot[10]=new Image("res/pot5.png");
			pot[9]=new Image("res/pot1.png");
	

		}
		else if (counter==7){
			pot[8]=new Image("res/pot0.png");
			pot[12]=new Image("res/pot5.png");
			pot[13]=new Image("res/pot1.png");
			pot[14]=new Image("res/pot5.png");
			pot[15]=new Image("res/pot5.png");
			pot[11]=new Image("res/pot5.png");
			pot[10]=new Image("res/pot5.png");
			pot[9]=new Image("res/pot1.png");
	

		}
		else if (counter==8){
			pot[8]=new Image("res/pot0.png");
			pot[12]=new Image("res/pot5.png");
			pot[13]=new Image("res/pot1.png");
			pot[14]=new Image("res/pot5.png");
			pot[15]=new Image("res/pot5.png");
			pot[11]=new Image("res/pot5.png");
			pot[10]=new Image("res/pot5.png");
			pot[9]=new Image("res/pot1.png");
	

		}
		else if (counter==9){
			pot[8]=new Image("res/pot0.png");
			pot[12]=new Image("res/pot5.png");
			pot[13]=new Image("res/pot1.png");
			pot[14]=new Image("res/pot5.png");
			pot[15]=new Image("res/pot5.png");
			pot[11]=new Image("res/pot5.png");
			pot[10]=new Image("res/pot5.png");
			pot[9]=new Image("res/pot1.png");
	
	
		}
		}
			//pot[12].wait(1000);
			//pot[8].wait(1000);
				

	
	
	public void loop9() throws SlickException{
		
		
		if(terry==1){
			pot[9]=new Image("res/pot0.png");
			pot[8]=new Image("res/pot4.png");
			pot[12]=new Image("res/pot4.png");
			pot[13]=new Image("res/pot0.png");
			pot[14]=new Image("res/pot4.png");
			pot[15]=new Image("res/pot4.png");
			pot[11]=new Image("res/pot4.png");
			pot[10]=new Image("res/pot4.png");
			}
			else if (counter==2){
				
				
						pot[8]=new Image("res/pot0.png");
						pot[12]=new Image("res/pot5.png");
						pot[13]=new Image("res/pot1.png");
						pot[14]=new Image("res/pot5.png");
						pot[15]=new Image("res/pot5.png");
						pot[11]=new Image("res/pot5.png");
						pot[10]=new Image("res/pot5.png");
						pot[9]=new Image("res/pot1.png");
				
				
				
				
				
				
				}
			
			else if (counter==3){
				pot[8]=new Image("res/pot0.png");
				pot[12]=new Image("res/pot5.png");
				pot[13]=new Image("res/pot1.png");
				pot[14]=new Image("res/pot5.png");
				pot[15]=new Image("res/pot5.png");
				pot[11]=new Image("res/pot5.png");
				pot[10]=new Image("res/pot5.png");
				pot[9]=new Image("res/pot1.png");
		

			}
			else if (counter==4){
				pot[8]=new Image("res/pot0.png");
				pot[12]=new Image("res/pot5.png");
				pot[13]=new Image("res/pot1.png");
				pot[14]=new Image("res/pot5.png");
				pot[15]=new Image("res/pot5.png");
				pot[11]=new Image("res/pot5.png");
				pot[10]=new Image("res/pot5.png");
				pot[9]=new Image("res/pot1.png");
		

			}
			else if (counter==5){
				pot[8]=new Image("res/pot0.png");
				pot[12]=new Image("res/pot5.png");
				pot[13]=new Image("res/pot1.png");
				pot[14]=new Image("res/pot5.png");
				pot[15]=new Image("res/pot5.png");
				pot[11]=new Image("res/pot5.png");
				pot[10]=new Image("res/pot5.png");
				pot[9]=new Image("res/pot1.png");
		

			}
			else if (counter==6){
				pot[8]=new Image("res/pot0.png");
				pot[12]=new Image("res/pot5.png");
				pot[13]=new Image("res/pot1.png");
				pot[14]=new Image("res/pot5.png");
				pot[15]=new Image("res/pot5.png");
				pot[11]=new Image("res/pot5.png");
				pot[10]=new Image("res/pot5.png");
				pot[9]=new Image("res/pot1.png");
		

			}
			else if (counter==7){
				pot[8]=new Image("res/pot0.png");
				pot[12]=new Image("res/pot5.png");
				pot[13]=new Image("res/pot1.png");
				pot[14]=new Image("res/pot5.png");
				pot[15]=new Image("res/pot5.png");
				pot[11]=new Image("res/pot5.png");
				pot[10]=new Image("res/pot5.png");
				pot[9]=new Image("res/pot1.png");
		

			}
			else if (counter==8){
				pot[8]=new Image("res/pot0.png");
				pot[12]=new Image("res/pot5.png");
				pot[13]=new Image("res/pot1.png");
				pot[14]=new Image("res/pot5.png");
				pot[15]=new Image("res/pot5.png");
				pot[11]=new Image("res/pot5.png");
				pot[10]=new Image("res/pot5.png");
				pot[9]=new Image("res/pot1.png");
		

			}
			else if (counter==9){
				pot[8]=new Image("res/pot0.png");
				pot[12]=new Image("res/pot5.png");
				pot[13]=new Image("res/pot1.png");
				pot[14]=new Image("res/pot5.png");
				pot[15]=new Image("res/pot5.png");
				pot[11]=new Image("res/pot5.png");
				pot[10]=new Image("res/pot5.png");
				pot[9]=new Image("res/pot1.png");
		
		
			}

	}
	public void loop8() throws SlickException{
		
		if(havad==1){
			pot[12]=new Image("res/pot0.png");
			pot[8]=new Image("res/pot4.png");
			pot[12]=new Image("res/pot4.png");
			pot[13]=new Image("res/pot0.png");
			pot[14]=new Image("res/pot4.png");
			pot[15]=new Image("res/pot4.png");
			pot[11]=new Image("res/pot4.png");
			pot[10]=new Image("res/pot4.png");
			}
			else if (counter==2){
				
				
						pot[8]=new Image("res/pot0.png");
						pot[12]=new Image("res/pot5.png");
						pot[13]=new Image("res/pot1.png");
						pot[14]=new Image("res/pot5.png");
						pot[15]=new Image("res/pot5.png");
						pot[11]=new Image("res/pot5.png");
						pot[10]=new Image("res/pot5.png");
						pot[9]=new Image("res/pot1.png");
				
				
				
				
				
				
				}
			
			else if (counter==3){
				pot[8]=new Image("res/pot0.png");
				pot[12]=new Image("res/pot5.png");
				pot[13]=new Image("res/pot1.png");
				pot[14]=new Image("res/pot5.png");
				pot[15]=new Image("res/pot5.png");
				pot[11]=new Image("res/pot5.png");
				pot[10]=new Image("res/pot5.png");
				pot[9]=new Image("res/pot1.png");
		

			}
			else if (counter==4){
				pot[8]=new Image("res/pot0.png");
				pot[12]=new Image("res/pot5.png");
				pot[13]=new Image("res/pot1.png");
				pot[14]=new Image("res/pot5.png");
				pot[15]=new Image("res/pot5.png");
				pot[11]=new Image("res/pot5.png");
				pot[10]=new Image("res/pot5.png");
				pot[9]=new Image("res/pot1.png");
		

			}
			else if (counter==5){
				pot[8]=new Image("res/pot0.png");
				pot[12]=new Image("res/pot5.png");
				pot[13]=new Image("res/pot1.png");
				pot[14]=new Image("res/pot5.png");
				pot[15]=new Image("res/pot5.png");
				pot[11]=new Image("res/pot5.png");
				pot[10]=new Image("res/pot5.png");
				pot[9]=new Image("res/pot1.png");
		

			}
			else if (counter==6){
				pot[8]=new Image("res/pot0.png");
				pot[12]=new Image("res/pot5.png");
				pot[13]=new Image("res/pot1.png");
				pot[14]=new Image("res/pot5.png");
				pot[15]=new Image("res/pot5.png");
				pot[11]=new Image("res/pot5.png");
				pot[10]=new Image("res/pot5.png");
				pot[9]=new Image("res/pot1.png");
		

			}
			else if (counter==7){
				pot[8]=new Image("res/pot0.png");
				pot[12]=new Image("res/pot5.png");
				pot[13]=new Image("res/pot1.png");
				pot[14]=new Image("res/pot5.png");
				pot[15]=new Image("res/pot5.png");
				pot[11]=new Image("res/pot5.png");
				pot[10]=new Image("res/pot5.png");
				pot[9]=new Image("res/pot1.png");
		

			}
			else if (counter==8){
				pot[8]=new Image("res/pot0.png");
				pot[12]=new Image("res/pot5.png");
				pot[13]=new Image("res/pot1.png");
				pot[14]=new Image("res/pot5.png");
				pot[15]=new Image("res/pot5.png");
				pot[11]=new Image("res/pot5.png");
				pot[10]=new Image("res/pot5.png");
				pot[9]=new Image("res/pot1.png");
		

			}
			else if (counter==9){
				pot[8]=new Image("res/pot0.png");
				pot[12]=new Image("res/pot5.png");
				pot[13]=new Image("res/pot1.png");
				pot[14]=new Image("res/pot5.png");
				pot[15]=new Image("res/pot5.png");
				pot[11]=new Image("res/pot5.png");
				pot[10]=new Image("res/pot5.png");
				pot[9]=new Image("res/pot1.png");
		
		
			}

	}
	public void loop12() throws SlickException{
		if(tango==1){
		pot[12]=new Image("res/pot0.png");
		pot[13]=new Image("res/pot4.png");
		pot[14]=new Image("res/pot4.png");
		pot[15]=new Image("res/pot0.png");
		pot[11]=new Image("res/pot4.png");
		pot[10]=new Image("res/pot4.png");
		pot[9]=new Image("res/pot4.png");
		pot[8]=new Image("res/pot4.png");
		}
		if(counter==1){
			pot[9]=new Image("res/pot0.png");
			pot[8]=new Image("res/pot4.png");
			pot[12]=new Image("res/pot4.png");
			pot[13]=new Image("res/pot0.png");
			pot[14]=new Image("res/pot4.png");
			pot[15]=new Image("res/pot4.png");
			pot[11]=new Image("res/pot4.png");
			pot[10]=new Image("res/pot4.png");
			}
			else if (counter==2){
				
				
						pot[8]=new Image("res/pot0.png");
						pot[12]=new Image("res/pot5.png");
						pot[13]=new Image("res/pot1.png");
						pot[14]=new Image("res/pot5.png");
						pot[15]=new Image("res/pot5.png");
						pot[11]=new Image("res/pot5.png");
						pot[10]=new Image("res/pot5.png");
						pot[9]=new Image("res/pot1.png");
				
				
				
				
				
				
				}
			
			else if (counter==3){
				pot[8]=new Image("res/pot0.png");
				pot[12]=new Image("res/pot5.png");
				pot[13]=new Image("res/pot1.png");
				pot[14]=new Image("res/pot5.png");
				pot[15]=new Image("res/pot5.png");
				pot[11]=new Image("res/pot5.png");
				pot[10]=new Image("res/pot5.png");
				pot[9]=new Image("res/pot1.png");
		

			}
			else if (counter==4){
				pot[8]=new Image("res/pot0.png");
				pot[12]=new Image("res/pot5.png");
				pot[13]=new Image("res/pot1.png");
				pot[14]=new Image("res/pot5.png");
				pot[15]=new Image("res/pot5.png");
				pot[11]=new Image("res/pot5.png");
				pot[10]=new Image("res/pot5.png");
				pot[9]=new Image("res/pot1.png");
		

			}
			else if (counter==5){
				pot[8]=new Image("res/pot0.png");
				pot[12]=new Image("res/pot5.png");
				pot[13]=new Image("res/pot1.png");
				pot[14]=new Image("res/pot5.png");
				pot[15]=new Image("res/pot5.png");
				pot[11]=new Image("res/pot5.png");
				pot[10]=new Image("res/pot5.png");
				pot[9]=new Image("res/pot1.png");
		

			}
			else if (counter==6){
				pot[8]=new Image("res/pot0.png");
				pot[12]=new Image("res/pot5.png");
				pot[13]=new Image("res/pot1.png");
				pot[14]=new Image("res/pot5.png");
				pot[15]=new Image("res/pot5.png");
				pot[11]=new Image("res/pot5.png");
				pot[10]=new Image("res/pot5.png");
				pot[9]=new Image("res/pot1.png");
		

			}
			else if (counter==7){
				pot[8]=new Image("res/pot0.png");
				pot[12]=new Image("res/pot5.png");
				pot[13]=new Image("res/pot1.png");
				pot[14]=new Image("res/pot5.png");
				pot[15]=new Image("res/pot5.png");
				pot[11]=new Image("res/pot5.png");
				pot[10]=new Image("res/pot5.png");
				pot[9]=new Image("res/pot1.png");
		

			}
			else if (counter==8){
				pot[8]=new Image("res/pot0.png");
				pot[12]=new Image("res/pot5.png");
				pot[13]=new Image("res/pot1.png");
				pot[14]=new Image("res/pot5.png");
				pot[15]=new Image("res/pot5.png");
				pot[11]=new Image("res/pot5.png");
				pot[10]=new Image("res/pot5.png");
				pot[9]=new Image("res/pot1.png");
		

			}
			else if (counter==9){
				pot[8]=new Image("res/pot0.png");
				pot[12]=new Image("res/pot5.png");
				pot[13]=new Image("res/pot1.png");
				pot[14]=new Image("res/pot5.png");
				pot[15]=new Image("res/pot5.png");
				pot[11]=new Image("res/pot5.png");
				pot[10]=new Image("res/pot5.png");
				pot[9]=new Image("res/pot1.png");
		
		
			}

	}
	public void loop13() throws SlickException{
		if(nasa==1){

		pot[13]=new Image("res/pot0.png");
		pot[14]=new Image("res/pot4.png");
		pot[15]=new Image("res/pot4.png");
		pot[11]=new Image("res/pot0.png");
		pot[10]=new Image("res/pot4.png");
		pot[9]=new Image("res/pot4.png");
		pot[8]=new Image("res/pot4.png");
		pot[12]=new Image("res/pot4.png");
		}
		if(counter==12){
			pot[9]=new Image("res/pot0.png");
			pot[8]=new Image("res/pot4.png");
			pot[12]=new Image("res/pot4.png");
			pot[13]=new Image("res/pot0.png");
			pot[14]=new Image("res/pot4.png");
			pot[15]=new Image("res/pot4.png");
			pot[11]=new Image("res/pot4.png");
			pot[10]=new Image("res/pot4.png");
			}
			else if (counter==2){
				
				
						pot[8]=new Image("res/pot0.png");
						pot[12]=new Image("res/pot5.png");
						pot[13]=new Image("res/pot1.png");
						pot[14]=new Image("res/pot5.png");
						pot[15]=new Image("res/pot5.png");
						pot[11]=new Image("res/pot5.png");
						pot[10]=new Image("res/pot5.png");
						pot[9]=new Image("res/pot1.png");
				
				
				
				
				
				
				}
			
			else if (counter==3){
				pot[8]=new Image("res/pot0.png");
				pot[12]=new Image("res/pot5.png");
				pot[13]=new Image("res/pot1.png");
				pot[14]=new Image("res/pot5.png");
				pot[15]=new Image("res/pot5.png");
				pot[11]=new Image("res/pot5.png");
				pot[10]=new Image("res/pot5.png");
				pot[9]=new Image("res/pot1.png");
		

			}
			else if (counter==4){
				pot[8]=new Image("res/pot0.png");
				pot[12]=new Image("res/pot5.png");
				pot[13]=new Image("res/pot1.png");
				pot[14]=new Image("res/pot5.png");
				pot[15]=new Image("res/pot5.png");
				pot[11]=new Image("res/pot5.png");
				pot[10]=new Image("res/pot5.png");
				pot[9]=new Image("res/pot1.png");
		

			}
			else if (counter==5){
				pot[8]=new Image("res/pot0.png");
				pot[12]=new Image("res/pot5.png");
				pot[13]=new Image("res/pot1.png");
				pot[14]=new Image("res/pot5.png");
				pot[15]=new Image("res/pot5.png");
				pot[11]=new Image("res/pot5.png");
				pot[10]=new Image("res/pot5.png");
				pot[9]=new Image("res/pot1.png");
		

			}
			else if (counter==6){
				pot[8]=new Image("res/pot0.png");
				pot[12]=new Image("res/pot5.png");
				pot[13]=new Image("res/pot1.png");
				pot[14]=new Image("res/pot5.png");
				pot[15]=new Image("res/pot5.png");
				pot[11]=new Image("res/pot5.png");
				pot[10]=new Image("res/pot5.png");
				pot[9]=new Image("res/pot1.png");
		

			}
			else if (counter==7){
				pot[8]=new Image("res/pot0.png");
				pot[12]=new Image("res/pot5.png");
				pot[13]=new Image("res/pot1.png");
				pot[14]=new Image("res/pot5.png");
				pot[15]=new Image("res/pot5.png");
				pot[11]=new Image("res/pot5.png");
				pot[10]=new Image("res/pot5.png");
				pot[9]=new Image("res/pot1.png");
		

			}
			else if (counter==8){
				pot[8]=new Image("res/pot0.png");
				pot[12]=new Image("res/pot5.png");
				pot[13]=new Image("res/pot1.png");
				pot[14]=new Image("res/pot5.png");
				pot[15]=new Image("res/pot5.png");
				pot[11]=new Image("res/pot5.png");
				pot[10]=new Image("res/pot5.png");
				pot[9]=new Image("res/pot1.png");
		

			}
			else if (counter==9){
				pot[8]=new Image("res/pot0.png");
				pot[12]=new Image("res/pot5.png");
				pot[13]=new Image("res/pot1.png");
				pot[14]=new Image("res/pot5.png");
				pot[15]=new Image("res/pot5.png");
				pot[11]=new Image("res/pot5.png");
				pot[10]=new Image("res/pot5.png");
				pot[9]=new Image("res/pot1.png");
		
		
			}

	}
	
	public void loop14() throws SlickException{
		if(oxfod==1){

		pot[14]=new Image("res/pot0.png");
		pot[15]=new Image("res/pot4.png");
		pot[11]=new Image("res/pot4.png");
		pot[10]=new Image("res/pot0.png");
		pot[9]=new Image("res/pot4.png");
		pot[8]=new Image("res/pot4.png");
		pot[12]=new Image("res/pot4.png");
		pot[13]=new Image("res/pot4.png");
		}
		if(counter==11){
			pot[9]=new Image("res/pot0.png");
			pot[8]=new Image("res/pot4.png");
			pot[12]=new Image("res/pot4.png");
			pot[13]=new Image("res/pot0.png");
			pot[14]=new Image("res/pot4.png");
			pot[15]=new Image("res/pot4.png");
			pot[11]=new Image("res/pot4.png");
			pot[10]=new Image("res/pot4.png");
			}
			else if (counter==2){
				
				
						pot[8]=new Image("res/pot0.png");
						pot[12]=new Image("res/pot5.png");
						pot[13]=new Image("res/pot1.png");
						pot[14]=new Image("res/pot5.png");
						pot[15]=new Image("res/pot5.png");
						pot[11]=new Image("res/pot5.png");
						pot[10]=new Image("res/pot5.png");
						pot[9]=new Image("res/pot1.png");
				
				
				
				
				
				
				}
			
			else if (counter==3){
				pot[8]=new Image("res/pot0.png");
				pot[12]=new Image("res/pot5.png");
				pot[13]=new Image("res/pot1.png");
				pot[14]=new Image("res/pot5.png");
				pot[15]=new Image("res/pot5.png");
				pot[11]=new Image("res/pot5.png");
				pot[10]=new Image("res/pot5.png");
				pot[9]=new Image("res/pot1.png");
		

			}
			else if (counter==4){
				pot[8]=new Image("res/pot0.png");
				pot[12]=new Image("res/pot5.png");
				pot[13]=new Image("res/pot1.png");
				pot[14]=new Image("res/pot5.png");
				pot[15]=new Image("res/pot5.png");
				pot[11]=new Image("res/pot5.png");
				pot[10]=new Image("res/pot5.png");
				pot[9]=new Image("res/pot1.png");
		

			}
			else if (counter==5){
				pot[8]=new Image("res/pot0.png");
				pot[12]=new Image("res/pot5.png");
				pot[13]=new Image("res/pot1.png");
				pot[14]=new Image("res/pot5.png");
				pot[15]=new Image("res/pot5.png");
				pot[11]=new Image("res/pot5.png");
				pot[10]=new Image("res/pot5.png");
				pot[9]=new Image("res/pot1.png");
		

			}
			else if (counter==6){
				pot[8]=new Image("res/pot0.png");
				pot[12]=new Image("res/pot5.png");
				pot[13]=new Image("res/pot1.png");
				pot[14]=new Image("res/pot5.png");
				pot[15]=new Image("res/pot5.png");
				pot[11]=new Image("res/pot5.png");
				pot[10]=new Image("res/pot5.png");
				pot[9]=new Image("res/pot1.png");
		

			}
			else if (counter==7){
				pot[8]=new Image("res/pot0.png");
				pot[12]=new Image("res/pot5.png");
				pot[13]=new Image("res/pot1.png");
				pot[14]=new Image("res/pot5.png");
				pot[15]=new Image("res/pot5.png");
				pot[11]=new Image("res/pot5.png");
				pot[10]=new Image("res/pot5.png");
				pot[9]=new Image("res/pot1.png");
		

			}
			else if (counter==8){
				pot[8]=new Image("res/pot0.png");
				pot[12]=new Image("res/pot5.png");
				pot[13]=new Image("res/pot1.png");
				pot[14]=new Image("res/pot5.png");
				pot[15]=new Image("res/pot5.png");
				pot[11]=new Image("res/pot5.png");
				pot[10]=new Image("res/pot5.png");
				pot[9]=new Image("res/pot1.png");
		

			}
			else if (counter==9){
				pot[8]=new Image("res/pot0.png");
				pot[12]=new Image("res/pot5.png");
				pot[13]=new Image("res/pot1.png");
				pot[14]=new Image("res/pot5.png");
				pot[15]=new Image("res/pot5.png");
				pot[11]=new Image("res/pot5.png");
				pot[10]=new Image("res/pot5.png");
				pot[9]=new Image("res/pot1.png");
		
		
			}

	}
	public void loop15() throws SlickException{
		if(erau==1){

		pot[15]=new Image("res/pot0.png");
		pot[11]=new Image("res/pot4.png");
		pot[10]=new Image("res/pot4.png");
		pot[9]=new Image("res/pot0.png");
		pot[8]=new Image("res/pot4.png");
		pot[12]=new Image("res/pot4.png");
		pot[13]=new Image("res/pot4.png");
		pot[14]=new Image("res/pot4.png");
		}
		if(counter==1){
			pot[9]=new Image("res/pot0.png");
			pot[8]=new Image("res/pot4.png");
			pot[12]=new Image("res/pot4.png");
			pot[13]=new Image("res/pot0.png");
			pot[14]=new Image("res/pot4.png");
			pot[15]=new Image("res/pot4.png");
			pot[11]=new Image("res/pot4.png");
			pot[10]=new Image("res/pot4.png");
			}
			else if (counter==2){
				
				
						pot[8]=new Image("res/pot0.png");
						pot[12]=new Image("res/pot5.png");
						pot[13]=new Image("res/pot1.png");
						pot[14]=new Image("res/pot5.png");
						pot[15]=new Image("res/pot5.png");
						pot[11]=new Image("res/pot5.png");
						pot[10]=new Image("res/pot5.png");
						pot[9]=new Image("res/pot1.png");
				
				
				
				
				
				
				}
			
			else if (counter==3){
				pot[8]=new Image("res/pot0.png");
				pot[12]=new Image("res/pot5.png");
				pot[13]=new Image("res/pot1.png");
				pot[14]=new Image("res/pot5.png");
				pot[15]=new Image("res/pot5.png");
				pot[11]=new Image("res/pot5.png");
				pot[10]=new Image("res/pot5.png");
				pot[9]=new Image("res/pot1.png");
		

			}
			else if (counter==4){
				pot[8]=new Image("res/pot0.png");
				pot[12]=new Image("res/pot5.png");
				pot[13]=new Image("res/pot1.png");
				pot[14]=new Image("res/pot5.png");
				pot[15]=new Image("res/pot5.png");
				pot[11]=new Image("res/pot5.png");
				pot[10]=new Image("res/pot5.png");
				pot[9]=new Image("res/pot1.png");
		

			}
			else if (counter==5){
				pot[8]=new Image("res/pot0.png");
				pot[12]=new Image("res/pot5.png");
				pot[13]=new Image("res/pot1.png");
				pot[14]=new Image("res/pot5.png");
				pot[15]=new Image("res/pot5.png");
				pot[11]=new Image("res/pot5.png");
				pot[10]=new Image("res/pot5.png");
				pot[9]=new Image("res/pot1.png");
		

			}
			else if (counter==6){
				pot[8]=new Image("res/pot0.png");
				pot[12]=new Image("res/pot5.png");
				pot[13]=new Image("res/pot1.png");
				pot[14]=new Image("res/pot5.png");
				pot[15]=new Image("res/pot5.png");
				pot[11]=new Image("res/pot5.png");
				pot[10]=new Image("res/pot5.png");
				pot[9]=new Image("res/pot1.png");
		

			}
			else if (counter==7){
				pot[8]=new Image("res/pot0.png");
				pot[12]=new Image("res/pot5.png");
				pot[13]=new Image("res/pot1.png");
				pot[14]=new Image("res/pot5.png");
				pot[15]=new Image("res/pot5.png");
				pot[11]=new Image("res/pot5.png");
				pot[10]=new Image("res/pot5.png");
				pot[9]=new Image("res/pot1.png");
		

			}
			else if (counter==8){
				pot[8]=new Image("res/pot0.png");
				pot[12]=new Image("res/pot5.png");
				pot[13]=new Image("res/pot1.png");
				pot[14]=new Image("res/pot5.png");
				pot[15]=new Image("res/pot5.png");
				pot[11]=new Image("res/pot5.png");
				pot[10]=new Image("res/pot5.png");
				pot[9]=new Image("res/pot1.png");
		

			}
			else if (counter==9){
				pot[8]=new Image("res/pot0.png");
				pot[12]=new Image("res/pot5.png");
				pot[13]=new Image("res/pot1.png");
				pot[14]=new Image("res/pot5.png");
				pot[15]=new Image("res/pot5.png");
				pot[11]=new Image("res/pot5.png");
				pot[10]=new Image("res/pot5.png");
				pot[9]=new Image("res/pot1.png");
		
		
			}

	}

	
	
	
	
	public void loop0() throws SlickException{
		if(counter==1){
		pot[10]=new Image("res/pot0.png");
		pot[9]=new Image("res/pot4.png");
		pot[8]=new Image("res/pot4.png");
		pot[12]=new Image("res/pot0.png");
		pot[13]=new Image("res/pot4.png");
		pot[14]=new Image("res/pot4.png");
		pot[15]=new Image("res/pot4.png");
		pot[11]=new Image("res/pot4.png");
		}
		if(counter==1){
			pot[9]=new Image("res/pot0.png");
			pot[8]=new Image("res/pot4.png");
			pot[12]=new Image("res/pot4.png");
			pot[13]=new Image("res/pot0.png");
			pot[14]=new Image("res/pot4.png");
			pot[15]=new Image("res/pot4.png");
			pot[11]=new Image("res/pot4.png");
			pot[10]=new Image("res/pot4.png");
			}
			else if (counter==2){
				
				
						pot[8]=new Image("res/pot0.png");
						pot[12]=new Image("res/pot5.png");
						pot[13]=new Image("res/pot1.png");
						pot[14]=new Image("res/pot5.png");
						pot[15]=new Image("res/pot5.png");
						pot[11]=new Image("res/pot5.png");
						pot[10]=new Image("res/pot5.png");
						pot[9]=new Image("res/pot1.png");
				
				
				
				
				
				
				}
			
			else if (counter==3){
				pot[8]=new Image("res/pot0.png");
				pot[12]=new Image("res/pot5.png");
				pot[13]=new Image("res/pot1.png");
				pot[14]=new Image("res/pot5.png");
				pot[15]=new Image("res/pot5.png");
				pot[11]=new Image("res/pot5.png");
				pot[10]=new Image("res/pot5.png");
				pot[9]=new Image("res/pot1.png");
		

			}
			else if (counter==4){
				pot[8]=new Image("res/pot0.png");
				pot[12]=new Image("res/pot5.png");
				pot[13]=new Image("res/pot1.png");
				pot[14]=new Image("res/pot5.png");
				pot[15]=new Image("res/pot5.png");
				pot[11]=new Image("res/pot5.png");
				pot[10]=new Image("res/pot5.png");
				pot[9]=new Image("res/pot1.png");
		

			}
			else if (counter==5){
				pot[8]=new Image("res/pot0.png");
				pot[12]=new Image("res/pot5.png");
				pot[13]=new Image("res/pot1.png");
				pot[14]=new Image("res/pot5.png");
				pot[15]=new Image("res/pot5.png");
				pot[11]=new Image("res/pot5.png");
				pot[10]=new Image("res/pot5.png");
				pot[9]=new Image("res/pot1.png");
		

			}
			else if (counter==6){
				pot[8]=new Image("res/pot0.png");
				pot[12]=new Image("res/pot5.png");
				pot[13]=new Image("res/pot1.png");
				pot[14]=new Image("res/pot5.png");
				pot[15]=new Image("res/pot5.png");
				pot[11]=new Image("res/pot5.png");
				pot[10]=new Image("res/pot5.png");
				pot[9]=new Image("res/pot1.png");
		

			}
			else if (counter==7){
				pot[8]=new Image("res/pot0.png");
				pot[12]=new Image("res/pot5.png");
				pot[13]=new Image("res/pot1.png");
				pot[14]=new Image("res/pot5.png");
				pot[15]=new Image("res/pot5.png");
				pot[11]=new Image("res/pot5.png");
				pot[10]=new Image("res/pot5.png");
				pot[9]=new Image("res/pot1.png");
		

			}
			else if (counter==8){
				pot[8]=new Image("res/pot0.png");
				pot[12]=new Image("res/pot5.png");
				pot[13]=new Image("res/pot1.png");
				pot[14]=new Image("res/pot5.png");
				pot[15]=new Image("res/pot5.png");
				pot[11]=new Image("res/pot5.png");
				pot[10]=new Image("res/pot5.png");
				pot[9]=new Image("res/pot1.png");
		

			}
			else if (counter==9){
				pot[8]=new Image("res/pot0.png");
				pot[12]=new Image("res/pot5.png");
				pot[13]=new Image("res/pot1.png");
				pot[14]=new Image("res/pot5.png");
				pot[15]=new Image("res/pot5.png");
				pot[11]=new Image("res/pot5.png");
				pot[10]=new Image("res/pot5.png");
				pot[9]=new Image("res/pot1.png");
		
		
			}

	} 
	
	public void loop1() throws SlickException{
		if(delta==1){

		pot[1]=new Image("res/pot0.png");
		pot[0]=new Image("res/pot4.png");
		pot[4]=new Image("res/pot4.png");
		pot[5]=new Image("res/pot0.png");
		pot[6]=new Image("res/pot4.png");
		pot[7]=new Image("res/pot4.png");
		pot[3]=new Image("res/pot4.png");
		pot[2]=new Image("res/pot4.png");
		}
		else if(counter==2){
			pot[9]=new Image("res/pot0.png");
			pot[8]=new Image("res/pot4.png");
			pot[12]=new Image("res/pot4.png");
			pot[13]=new Image("res/pot0.png");
			pot[14]=new Image("res/pot4.png");
			pot[15]=new Image("res/pot4.png");
			pot[11]=new Image("res/pot4.png");
			pot[10]=new Image("res/pot4.png");
			}
			else if (counter==3){
				
				
						pot[8]=new Image("res/pot0.png");
						pot[12]=new Image("res/pot5.png");
						pot[13]=new Image("res/pot1.png");
						pot[14]=new Image("res/pot5.png");
						pot[15]=new Image("res/pot5.png");
						pot[11]=new Image("res/pot5.png");
						pot[10]=new Image("res/pot5.png");
						pot[9]=new Image("res/pot1.png");
				
				
				
				
				
				
				}
			
			else if (counter==4){
				pot[8]=new Image("res/pot0.png");
				pot[12]=new Image("res/pot5.png");
				pot[13]=new Image("res/pot1.png");
				pot[14]=new Image("res/pot5.png");
				pot[15]=new Image("res/pot5.png");
				pot[11]=new Image("res/pot5.png");
				pot[10]=new Image("res/pot5.png");
				pot[9]=new Image("res/pot1.png");
		

			}
			else if (counter==5){
				pot[8]=new Image("res/pot0.png");
				pot[12]=new Image("res/pot5.png");
				pot[13]=new Image("res/pot1.png");
				pot[14]=new Image("res/pot5.png");
				pot[15]=new Image("res/pot5.png");
				pot[11]=new Image("res/pot5.png");
				pot[10]=new Image("res/pot5.png");
				pot[9]=new Image("res/pot1.png");
		

			}
			else if (counter==6){
				pot[8]=new Image("res/pot0.png");
				pot[12]=new Image("res/pot5.png");
				pot[13]=new Image("res/pot1.png");
				pot[14]=new Image("res/pot5.png");
				pot[15]=new Image("res/pot5.png");
				pot[11]=new Image("res/pot5.png");
				pot[10]=new Image("res/pot5.png");
				pot[9]=new Image("res/pot1.png");
		

			}
			else if (counter==7){
				pot[8]=new Image("res/pot0.png");
				pot[12]=new Image("res/pot5.png");
				pot[13]=new Image("res/pot1.png");
				pot[14]=new Image("res/pot5.png");
				pot[15]=new Image("res/pot5.png");
				pot[11]=new Image("res/pot5.png");
				pot[10]=new Image("res/pot5.png");
				pot[9]=new Image("res/pot1.png");
		

			}
			else if (counter==8){
				pot[8]=new Image("res/pot0.png");
				pot[12]=new Image("res/pot5.png");
				pot[13]=new Image("res/pot1.png");
				pot[14]=new Image("res/pot5.png");
				pot[15]=new Image("res/pot5.png");
				pot[11]=new Image("res/pot5.png");
				pot[10]=new Image("res/pot5.png");
				pot[9]=new Image("res/pot1.png");
		

			}
			else if (counter==9){
				pot[8]=new Image("res/pot0.png");
				pot[12]=new Image("res/pot5.png");
				pot[13]=new Image("res/pot1.png");
				pot[14]=new Image("res/pot5.png");
				pot[15]=new Image("res/pot5.png");
				pot[11]=new Image("res/pot5.png");
				pot[10]=new Image("res/pot5.png");
				pot[9]=new Image("res/pot1.png");
		

			}
			else if (counter==10){
				pot[8]=new Image("res/pot0.png");
				pot[12]=new Image("res/pot5.png");
				pot[13]=new Image("res/pot1.png");
				pot[14]=new Image("res/pot5.png");
				pot[15]=new Image("res/pot5.png");
				pot[11]=new Image("res/pot5.png");
				pot[10]=new Image("res/pot5.png");
				pot[9]=new Image("res/pot1.png");
		
		
			}

	}
	
	public void loop2() throws SlickException{
		if(stan==1){

		pot[2]=new Image("res/pot0.png");
		pot[1]=new Image("res/pot4.png");
		pot[0]=new Image("res/pot4.png");
		pot[4]=new Image("res/pot0.png");
		pot[5]=new Image("res/pot4.png");
		pot[6]=new Image("res/pot4.png");
		pot[7]=new Image("res/pot4.png");
		pot[3]=new Image("res/pot4.png");
		}
		if(counter==11){
			pot[9]=new Image("res/pot0.png");
			pot[8]=new Image("res/pot4.png");
			pot[12]=new Image("res/pot4.png");
			pot[13]=new Image("res/pot0.png");
			pot[14]=new Image("res/pot4.png");
			pot[15]=new Image("res/pot4.png");
			pot[11]=new Image("res/pot4.png");
			pot[10]=new Image("res/pot4.png");
			}
			else if (counter==2){
				
				
						pot[8]=new Image("res/pot0.png");
						pot[12]=new Image("res/pot5.png");
						pot[13]=new Image("res/pot1.png");
						pot[14]=new Image("res/pot5.png");
						pot[15]=new Image("res/pot5.png");
						pot[11]=new Image("res/pot5.png");
						pot[10]=new Image("res/pot5.png");
						pot[9]=new Image("res/pot1.png");
				
				
				
				
				
				
				}
			
			else if (counter==3){
				pot[8]=new Image("res/pot0.png");
				pot[12]=new Image("res/pot5.png");
				pot[13]=new Image("res/pot1.png");
				pot[14]=new Image("res/pot5.png");
				pot[15]=new Image("res/pot5.png");
				pot[11]=new Image("res/pot5.png");
				pot[10]=new Image("res/pot5.png");
				pot[9]=new Image("res/pot1.png");
		

			}
			else if (counter==4){
				pot[8]=new Image("res/pot0.png");
				pot[12]=new Image("res/pot5.png");
				pot[13]=new Image("res/pot1.png");
				pot[14]=new Image("res/pot5.png");
				pot[15]=new Image("res/pot5.png");
				pot[11]=new Image("res/pot5.png");
				pot[10]=new Image("res/pot5.png");
				pot[9]=new Image("res/pot1.png");
		

			}
			else if (counter==5){
				pot[8]=new Image("res/pot0.png");
				pot[12]=new Image("res/pot5.png");
				pot[13]=new Image("res/pot1.png");
				pot[14]=new Image("res/pot5.png");
				pot[15]=new Image("res/pot5.png");
				pot[11]=new Image("res/pot5.png");
				pot[10]=new Image("res/pot5.png");
				pot[9]=new Image("res/pot1.png");
		

			}
			else if (counter==6){
				pot[8]=new Image("res/pot0.png");
				pot[12]=new Image("res/pot5.png");
				pot[13]=new Image("res/pot1.png");
				pot[14]=new Image("res/pot5.png");
				pot[15]=new Image("res/pot5.png");
				pot[11]=new Image("res/pot5.png");
				pot[10]=new Image("res/pot5.png");
				pot[9]=new Image("res/pot1.png");
		

			}
			else if (counter==7){
				pot[8]=new Image("res/pot0.png");
				pot[12]=new Image("res/pot5.png");
				pot[13]=new Image("res/pot1.png");
				pot[14]=new Image("res/pot5.png");
				pot[15]=new Image("res/pot5.png");
				pot[11]=new Image("res/pot5.png");
				pot[10]=new Image("res/pot5.png");
				pot[9]=new Image("res/pot1.png");
		

			}
			else if (counter==8){
				pot[8]=new Image("res/pot0.png");
				pot[12]=new Image("res/pot5.png");
				pot[13]=new Image("res/pot1.png");
				pot[14]=new Image("res/pot5.png");
				pot[15]=new Image("res/pot5.png");
				pot[11]=new Image("res/pot5.png");
				pot[10]=new Image("res/pot5.png");
				pot[9]=new Image("res/pot1.png");
		

			}
			else if (counter==9){
				pot[8]=new Image("res/pot0.png");
				pot[12]=new Image("res/pot5.png");
				pot[13]=new Image("res/pot1.png");
				pot[14]=new Image("res/pot5.png");
				pot[15]=new Image("res/pot5.png");
				pot[11]=new Image("res/pot5.png");
				pot[10]=new Image("res/pot5.png");
				pot[9]=new Image("res/pot1.png");
		
		
			}

		
	}
	public void loop3() throws SlickException{
		if(chali==1){

		pot[3]=new Image("res/pot0.png");
		pot[2]=new Image("res/pot4.png");
		pot[1]=new Image("res/pot4.png");
		pot[0]=new Image("res/pot4.png");
		}
				if(counter==11){
			pot[9]=new Image("res/pot0.png");
			pot[8]=new Image("res/pot4.png");
			pot[12]=new Image("res/pot4.png");
			pot[13]=new Image("res/pot0.png");
			pot[14]=new Image("res/pot4.png");
			pot[15]=new Image("res/pot4.png");
			pot[11]=new Image("res/pot4.png");
			pot[10]=new Image("res/pot4.png");
			}
			else if (counter==2){
				
				
						pot[8]=new Image("res/pot0.png");
						pot[12]=new Image("res/pot5.png");
						pot[13]=new Image("res/pot1.png");
						pot[14]=new Image("res/pot5.png");
						pot[15]=new Image("res/pot5.png");
						pot[11]=new Image("res/pot5.png");
						pot[10]=new Image("res/pot5.png");
						pot[9]=new Image("res/pot1.png");
				
				
				
				
				
				
				}
			
			else if (counter==3){
				pot[8]=new Image("res/pot0.png");
				pot[12]=new Image("res/pot5.png");
				pot[13]=new Image("res/pot1.png");
				pot[14]=new Image("res/pot5.png");
				pot[15]=new Image("res/pot5.png");
				pot[11]=new Image("res/pot5.png");
				pot[10]=new Image("res/pot5.png");
				pot[9]=new Image("res/pot1.png");
		

			}
			else if (counter==4){
				pot[8]=new Image("res/pot0.png");
				pot[12]=new Image("res/pot5.png");
				pot[13]=new Image("res/pot1.png");
				pot[14]=new Image("res/pot5.png");
				pot[15]=new Image("res/pot5.png");
				pot[11]=new Image("res/pot5.png");
				pot[10]=new Image("res/pot5.png");
				pot[9]=new Image("res/pot1.png");
		

			}
			else if (counter==5){
				pot[8]=new Image("res/pot0.png");
				pot[12]=new Image("res/pot5.png");
				pot[13]=new Image("res/pot1.png");
				pot[14]=new Image("res/pot5.png");
				pot[15]=new Image("res/pot5.png");
				pot[11]=new Image("res/pot5.png");
				pot[10]=new Image("res/pot5.png");
				pot[9]=new Image("res/pot1.png");
		

			}
			else if (counter==6){
				pot[8]=new Image("res/pot0.png");
				pot[12]=new Image("res/pot5.png");
				pot[13]=new Image("res/pot1.png");
				pot[14]=new Image("res/pot5.png");
				pot[15]=new Image("res/pot5.png");
				pot[11]=new Image("res/pot5.png");
				pot[10]=new Image("res/pot5.png");
				pot[9]=new Image("res/pot1.png");
		

			}
			else if (counter==7){
				pot[8]=new Image("res/pot0.png");
				pot[12]=new Image("res/pot5.png");
				pot[13]=new Image("res/pot1.png");
				pot[14]=new Image("res/pot5.png");
				pot[15]=new Image("res/pot5.png");
				pot[11]=new Image("res/pot5.png");
				pot[10]=new Image("res/pot5.png");
				pot[9]=new Image("res/pot1.png");
		

			}
			else if (counter==8){
				pot[8]=new Image("res/pot0.png");
				pot[12]=new Image("res/pot5.png");
				pot[13]=new Image("res/pot1.png");
				pot[14]=new Image("res/pot5.png");
				pot[15]=new Image("res/pot5.png");
				pot[11]=new Image("res/pot5.png");
				pot[10]=new Image("res/pot5.png");
				pot[9]=new Image("res/pot1.png");
		

			}
			else if (counter==9){
				pot[8]=new Image("res/pot0.png");
				pot[12]=new Image("res/pot5.png");
				pot[13]=new Image("res/pot1.png");
				pot[14]=new Image("res/pot5.png");
				pot[15]=new Image("res/pot5.png");
				pot[11]=new Image("res/pot5.png");
				pot[10]=new Image("res/pot5.png");
				pot[9]=new Image("res/pot1.png");
		
		
			}

	}
	public void loop4() throws SlickException{
		if(cambi==1){

		pot[4]=new Image("res/pot0.png");
		pot[5]=new Image("res/pot4.png");
		pot[15]=new Image("res/pot4.png");
		pot[11]=new Image("res/pot0.png");
		pot[10]=new Image("res/pot4.png");
		pot[9]=new Image("res/pot4.png");
		pot[8]=new Image("res/pot4.png");
		pot[12]=new Image("res/pot4.png");
		}
		else if(counter==1){
			pot[9]=new Image("res/pot0.png");
			pot[8]=new Image("res/pot4.png");
			pot[12]=new Image("res/pot4.png");
			pot[13]=new Image("res/pot0.png");
			pot[14]=new Image("res/pot4.png");
			pot[15]=new Image("res/pot4.png");
			pot[11]=new Image("res/pot4.png");
			pot[10]=new Image("res/pot4.png");
			}
			else if (counter==2){
				
				
						pot[8]=new Image("res/pot0.png");
						pot[12]=new Image("res/pot5.png");
						pot[13]=new Image("res/pot1.png");
						pot[14]=new Image("res/pot5.png");
						pot[15]=new Image("res/pot5.png");
						pot[11]=new Image("res/pot5.png");
						pot[10]=new Image("res/pot5.png");
						pot[9]=new Image("res/pot1.png");
				
				
				
				
				
				
				}
			
			else if (counter==3){
				pot[8]=new Image("res/pot0.png");
				pot[12]=new Image("res/pot5.png");
				pot[13]=new Image("res/pot1.png");
				pot[14]=new Image("res/pot5.png");
				pot[15]=new Image("res/pot5.png");
				pot[11]=new Image("res/pot5.png");
				pot[10]=new Image("res/pot5.png");
				pot[9]=new Image("res/pot1.png");
		

			}
			else if (counter==4){
				pot[8]=new Image("res/pot0.png");
				pot[12]=new Image("res/pot5.png");
				pot[13]=new Image("res/pot1.png");
				pot[14]=new Image("res/pot5.png");
				pot[15]=new Image("res/pot5.png");
				pot[11]=new Image("res/pot5.png");
				pot[10]=new Image("res/pot5.png");
				pot[9]=new Image("res/pot1.png");
		

			}
			else if (counter==5){
				pot[8]=new Image("res/pot0.png");
				pot[12]=new Image("res/pot5.png");
				pot[13]=new Image("res/pot1.png");
				pot[14]=new Image("res/pot5.png");
				pot[15]=new Image("res/pot5.png");
				pot[11]=new Image("res/pot5.png");
				pot[10]=new Image("res/pot5.png");
				pot[9]=new Image("res/pot1.png");
		

			}
			else if (counter==6){
				pot[8]=new Image("res/pot0.png");
				pot[12]=new Image("res/pot5.png");
				pot[13]=new Image("res/pot1.png");
				pot[14]=new Image("res/pot5.png");
				pot[15]=new Image("res/pot5.png");
				pot[11]=new Image("res/pot5.png");
				pot[10]=new Image("res/pot5.png");
				pot[9]=new Image("res/pot1.png");
		

			}
			else if (counter==7){
				pot[8]=new Image("res/pot0.png");
				pot[12]=new Image("res/pot5.png");
				pot[13]=new Image("res/pot1.png");
				pot[14]=new Image("res/pot5.png");
				pot[15]=new Image("res/pot5.png");
				pot[11]=new Image("res/pot5.png");
				pot[10]=new Image("res/pot5.png");
				pot[9]=new Image("res/pot1.png");
		

			}
			else if (counter==8){
				pot[8]=new Image("res/pot0.png");
				pot[12]=new Image("res/pot5.png");
				pot[13]=new Image("res/pot1.png");
				pot[14]=new Image("res/pot5.png");
				pot[15]=new Image("res/pot5.png");
				pot[11]=new Image("res/pot5.png");
				pot[10]=new Image("res/pot5.png");
				pot[9]=new Image("res/pot1.png");
		

			}
			else if (counter==9){
				pot[8]=new Image("res/pot0.png");
				pot[12]=new Image("res/pot5.png");
				pot[13]=new Image("res/pot1.png");
				pot[14]=new Image("res/pot5.png");
				pot[15]=new Image("res/pot5.png");
				pot[11]=new Image("res/pot5.png");
				pot[10]=new Image("res/pot5.png");
				pot[9]=new Image("res/pot1.png");
		
		
			}

	}
	public void loop5() throws SlickException{
		
		if(millij==1){
		pot[5]=new Image("res/pot0.png");
		pot[6]=new Image("res/pot4.png");
		pot[7]=new Image("res/pot4.png");
		pot[3]=new Image("res/pot0.png");
		pot[2]=new Image("res/pot4.png");
		pot[1]=new Image("res/pot4.png");
		pot[0]=new Image("res/pot4.png");
		pot[4]=new Image("res/pot4.png");
		}
		if(counter==1){
			pot[9]=new Image("res/pot0.png");
			pot[8]=new Image("res/pot4.png");
			pot[12]=new Image("res/pot4.png");
			pot[13]=new Image("res/pot0.png");
			pot[14]=new Image("res/pot4.png");
			pot[15]=new Image("res/pot4.png");
			pot[11]=new Image("res/pot4.png");
			pot[10]=new Image("res/pot4.png");
			}
			else if (counter==2){
				
				
						pot[8]=new Image("res/pot0.png");
						pot[12]=new Image("res/pot5.png");
						pot[13]=new Image("res/pot1.png");
						pot[14]=new Image("res/pot5.png");
						pot[15]=new Image("res/pot5.png");
						pot[11]=new Image("res/pot5.png");
						pot[10]=new Image("res/pot5.png");
						pot[9]=new Image("res/pot1.png");
				
				
				
				
				
				
				}
			
			else if (counter==3){
				pot[8]=new Image("res/pot0.png");
				pot[12]=new Image("res/pot5.png");
				pot[13]=new Image("res/pot1.png");
				pot[14]=new Image("res/pot5.png");
				pot[15]=new Image("res/pot5.png");
				pot[11]=new Image("res/pot5.png");
				pot[10]=new Image("res/pot5.png");
				pot[9]=new Image("res/pot1.png");
		

			}
			else if (counter==4){
				pot[8]=new Image("res/pot0.png");
				pot[12]=new Image("res/pot5.png");
				pot[13]=new Image("res/pot1.png");
				pot[14]=new Image("res/pot5.png");
				pot[15]=new Image("res/pot5.png");
				pot[11]=new Image("res/pot5.png");
				pot[10]=new Image("res/pot5.png");
				pot[9]=new Image("res/pot1.png");
		

			}
			else if (counter==5){
				pot[8]=new Image("res/pot0.png");
				pot[12]=new Image("res/pot5.png");
				pot[13]=new Image("res/pot1.png");
				pot[14]=new Image("res/pot5.png");
				pot[15]=new Image("res/pot5.png");
				pot[11]=new Image("res/pot5.png");
				pot[10]=new Image("res/pot5.png");
				pot[9]=new Image("res/pot1.png");
		

			}
			else if (counter==6){
				pot[8]=new Image("res/pot0.png");
				pot[12]=new Image("res/pot5.png");
				pot[13]=new Image("res/pot1.png");
				pot[14]=new Image("res/pot5.png");
				pot[15]=new Image("res/pot5.png");
				pot[11]=new Image("res/pot5.png");
				pot[10]=new Image("res/pot5.png");
				pot[9]=new Image("res/pot1.png");
		

			}
			else if (counter==7){
				pot[8]=new Image("res/pot0.png");
				pot[12]=new Image("res/pot5.png");
				pot[13]=new Image("res/pot1.png");
				pot[14]=new Image("res/pot5.png");
				pot[15]=new Image("res/pot5.png");
				pot[11]=new Image("res/pot5.png");
				pot[10]=new Image("res/pot5.png");
				pot[9]=new Image("res/pot1.png");
		

			}
			else if (counter==8){
				pot[8]=new Image("res/pot0.png");
				pot[12]=new Image("res/pot5.png");
				pot[13]=new Image("res/pot1.png");
				pot[14]=new Image("res/pot5.png");
				pot[15]=new Image("res/pot5.png");
				pot[11]=new Image("res/pot5.png");
				pot[10]=new Image("res/pot5.png");
				pot[9]=new Image("res/pot1.png");
		

			}
			else if (counter==9){
				pot[8]=new Image("res/pot0.png");
				pot[12]=new Image("res/pot5.png");
				pot[13]=new Image("res/pot1.png");
				pot[14]=new Image("res/pot5.png");
				pot[15]=new Image("res/pot5.png");
				pot[11]=new Image("res/pot5.png");
				pot[10]=new Image("res/pot5.png");
				pot[9]=new Image("res/pot1.png");
		
		
			}

	}
	
	public void loop6() throws SlickException{
		if(loyd==1){
		pot[6]=new Image("res/pot0.png");
		pot[7]=new Image("res/pot4.png");
		pot[3]=new Image("res/pot4.png");
		pot[2]=new Image("res/pot0.png");
		pot[1]=new Image("res/pot4.png");
		pot[0]=new Image("res/pot4.png");
		pot[4]=new Image("res/pot4.png");
		pot[5]=new Image("res/pot4.png");
		}
		if(counter==11){
			pot[9]=new Image("res/pot0.png");
			pot[8]=new Image("res/pot4.png");
			pot[12]=new Image("res/pot4.png");
			pot[13]=new Image("res/pot0.png");
			pot[14]=new Image("res/pot4.png");
			pot[15]=new Image("res/pot4.png");
			pot[11]=new Image("res/pot4.png");
			pot[10]=new Image("res/pot4.png");
			}
			else if (counter==2){
				
				
						pot[8]=new Image("res/pot0.png");
						pot[12]=new Image("res/pot5.png");
						pot[13]=new Image("res/pot1.png");
						pot[14]=new Image("res/pot5.png");
						pot[15]=new Image("res/pot5.png");
						pot[11]=new Image("res/pot5.png");
						pot[10]=new Image("res/pot5.png");
						pot[9]=new Image("res/pot1.png");
				
				
				
				
				
				
				}
			
			else if (counter==3){
				pot[8]=new Image("res/pot0.png");
				pot[12]=new Image("res/pot5.png");
				pot[13]=new Image("res/pot1.png");
				pot[14]=new Image("res/pot5.png");
				pot[15]=new Image("res/pot5.png");
				pot[11]=new Image("res/pot5.png");
				pot[10]=new Image("res/pot5.png");
				pot[9]=new Image("res/pot1.png");
		

			}
			else if (counter==4){
				pot[8]=new Image("res/pot0.png");
				pot[12]=new Image("res/pot5.png");
				pot[13]=new Image("res/pot1.png");
				pot[14]=new Image("res/pot5.png");
				pot[15]=new Image("res/pot5.png");
				pot[11]=new Image("res/pot5.png");
				pot[10]=new Image("res/pot5.png");
				pot[9]=new Image("res/pot1.png");
		

			}
			else if (counter==5){
				pot[8]=new Image("res/pot0.png");
				pot[12]=new Image("res/pot5.png");
				pot[13]=new Image("res/pot1.png");
				pot[14]=new Image("res/pot5.png");
				pot[15]=new Image("res/pot5.png");
				pot[11]=new Image("res/pot5.png");
				pot[10]=new Image("res/pot5.png");
				pot[9]=new Image("res/pot1.png");
		

			}
			else if (counter==6){
				pot[8]=new Image("res/pot0.png");
				pot[12]=new Image("res/pot5.png");
				pot[13]=new Image("res/pot1.png");
				pot[14]=new Image("res/pot5.png");
				pot[15]=new Image("res/pot5.png");
				pot[11]=new Image("res/pot5.png");
				pot[10]=new Image("res/pot5.png");
				pot[9]=new Image("res/pot1.png");
		

			}
			else if (counter==7){
				pot[8]=new Image("res/pot0.png");
				pot[12]=new Image("res/pot5.png");
				pot[13]=new Image("res/pot1.png");
				pot[14]=new Image("res/pot5.png");
				pot[15]=new Image("res/pot5.png");
				pot[11]=new Image("res/pot5.png");
				pot[10]=new Image("res/pot5.png");
				pot[9]=new Image("res/pot1.png");
		

			}
			else if (counter==8){
				pot[8]=new Image("res/pot0.png");
				pot[12]=new Image("res/pot5.png");
				pot[13]=new Image("res/pot1.png");
				pot[14]=new Image("res/pot5.png");
				pot[15]=new Image("res/pot5.png");
				pot[11]=new Image("res/pot5.png");
				pot[10]=new Image("res/pot5.png");
				pot[9]=new Image("res/pot1.png");
		

			}
			else if (counter==9){
				pot[8]=new Image("res/pot0.png");
				pot[12]=new Image("res/pot5.png");
				pot[13]=new Image("res/pot1.png");
				pot[14]=new Image("res/pot5.png");
				pot[15]=new Image("res/pot5.png");
				pot[11]=new Image("res/pot5.png");
				pot[10]=new Image("res/pot5.png");
				pot[9]=new Image("res/pot1.png");
		
		
			}

	}
	public void loop7() throws SlickException{
		if(hit==1){
		pot[7]=new Image("res/pot0.png");
		pot[3]=new Image("res/pot4.png");
		pot[2]=new Image("res/pot4.png");
		pot[1]=new Image("res/pot0.png");
		pot[0]=new Image("res/pot4.png");
		pot[4]=new Image("res/pot4.png");
		pot[5]=new Image("res/pot4.png");
		pot[6]=new Image("res/pot4.png");
		}
		if(counter==11){
			pot[9]=new Image("res/pot0.png");
			pot[8]=new Image("res/pot4.png");
			pot[12]=new Image("res/pot4.png");
			pot[13]=new Image("res/pot0.png");
			pot[14]=new Image("res/pot4.png");
			pot[15]=new Image("res/pot4.png");
			pot[11]=new Image("res/pot4.png");
			pot[10]=new Image("res/pot4.png");
			}
			else if (counter==2){
				
				
						pot[8]=new Image("res/pot0.png");
						pot[12]=new Image("res/pot5.png");
						pot[13]=new Image("res/pot1.png");
						pot[14]=new Image("res/pot5.png");
						pot[15]=new Image("res/pot5.png");
						pot[11]=new Image("res/pot5.png");
						pot[10]=new Image("res/pot5.png");
						pot[9]=new Image("res/pot1.png");
				
				
				
				
				
				
				}
			
			else if (counter==3){
				pot[8]=new Image("res/pot0.png");
				pot[12]=new Image("res/pot5.png");
				pot[13]=new Image("res/pot1.png");
				pot[14]=new Image("res/pot5.png");
				pot[15]=new Image("res/pot5.png");
				pot[11]=new Image("res/pot5.png");
				pot[10]=new Image("res/pot5.png");
				pot[9]=new Image("res/pot1.png");
		

			}
			else if (counter==4){
				pot[8]=new Image("res/pot0.png");
				pot[12]=new Image("res/pot5.png");
				pot[13]=new Image("res/pot1.png");
				pot[14]=new Image("res/pot5.png");
				pot[15]=new Image("res/pot5.png");
				pot[11]=new Image("res/pot5.png");
				pot[10]=new Image("res/pot5.png");
				pot[9]=new Image("res/pot1.png");
		

			}
			else if (counter==5){
				pot[8]=new Image("res/pot0.png");
				pot[12]=new Image("res/pot5.png");
				pot[13]=new Image("res/pot1.png");
				pot[14]=new Image("res/pot5.png");
				pot[15]=new Image("res/pot5.png");
				pot[11]=new Image("res/pot5.png");
				pot[10]=new Image("res/pot5.png");
				pot[9]=new Image("res/pot1.png");
		

			}
			else if (counter==6){
				pot[8]=new Image("res/pot0.png");
				pot[12]=new Image("res/pot5.png");
				pot[13]=new Image("res/pot1.png");
				pot[14]=new Image("res/pot5.png");
				pot[15]=new Image("res/pot5.png");
				pot[11]=new Image("res/pot5.png");
				pot[10]=new Image("res/pot5.png");
				pot[9]=new Image("res/pot1.png");
		

			}
			else if (counter==7){
				pot[8]=new Image("res/pot0.png");
				pot[12]=new Image("res/pot5.png");
				pot[13]=new Image("res/pot1.png");
				pot[14]=new Image("res/pot5.png");
				pot[15]=new Image("res/pot5.png");
				pot[11]=new Image("res/pot5.png");
				pot[10]=new Image("res/pot5.png");
				pot[9]=new Image("res/pot1.png");
		

			}
			else if (counter==8){
				pot[8]=new Image("res/pot0.png");
				pot[12]=new Image("res/pot5.png");
				pot[13]=new Image("res/pot1.png");
				pot[14]=new Image("res/pot5.png");
				pot[15]=new Image("res/pot5.png");
				pot[11]=new Image("res/pot5.png");
				pot[10]=new Image("res/pot5.png");
				pot[9]=new Image("res/pot1.png");
		

			}
			else if (counter==9){
				pot[8]=new Image("res/pot0.png");
				pot[12]=new Image("res/pot5.png");
				pot[13]=new Image("res/pot1.png");
				pot[14]=new Image("res/pot5.png");
				pot[15]=new Image("res/pot5.png");
				pot[11]=new Image("res/pot5.png");
				pot[10]=new Image("res/pot5.png");
				pot[9]=new Image("res/pot1.png");
		
		
			}

	}

	
public void Sleep(int t){
	t=2000;
	
	return;
}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
public Play(int state){
//	pots=new LinkedList<Pot>();
    }







public void init(GameContainer gc,StateBasedGame sbg) throws SlickException{
	//palmdown[0]=new Image("res/palmdown.png");	
	fistdown=new Image("res/1397184166_whole_hand.png");
	menu=new Image("res/menu_pull_up.png");
	exit=new Image("res/Locked_Cell_Door.png");
	back=new Image("res/1506189.jpg");
	gz=new Image("res/Great-Zimbabwe-BW-650px.jpg");
	for(i=0;i<16;i++){
			 pot[i]=new Image("res/pot3.png");

}}



public void render(GameContainer gc,StateBasedGame sbg,Graphics g) throws SlickException{
	
	
	
	//g.drawRect(110,100,520,390);
	//g.setClip(110,100,520,390);

	gz.draw(0,0,2.8f);
	back.draw(320,120,0.8f);
	g.drawString(":PLAYER 2",900,200);
	g.drawString(":PLAYER 1",900,350);

	//g.fillOval(110,100,520,390);
	g.setColor(org.newdawn.slick.Color.yellow);

	g.drawImage(pot[0],400,150 );
	g.drawImage(pot[1],500,150 );
	g.drawImage(pot[2],600,150 );
	g.drawImage(pot[3],700,150);
	g.drawImage(pot[4],400,200 );
	g.drawImage(pot[5],500,200 );
	g.drawImage(pot[6],600,200 );
	g.drawImage(pot[7],700,200 );
	g.drawImage(pot[8],400,300 );
	g.drawImage(pot[9],500,300 );
	g.drawImage(pot[10],600,300 );
	g.drawImage(pot[11],700,300 );
	
	g.drawImage(pot[12],400,350 );
	g.drawImage(pot[13],500,350 );
	g.drawImage(pot[14],600,350 );
	g.drawImage(pot[15],700,350 );
	//g.drawImage(fistdown, fistdownx, fistdowny );

	
	g.drawImage(menu,300,600);
	g.drawImage(exit,900,590);
		
	//g.drawImage(fistdown[0],fistdownx,fistdowny);
		//g.drawOval(90,590,100,40);//FOR START
	
	g.drawString("MENU",310,690);
	g.drawString("EXIT",910,690);
	g.drawString(mouse ,50,50);
	//g.drawRect(200,150,340,250);//FOR RECTANGLE
//	g.fillRect(color.100,100,530,400);
g.getColor();
	//g.drawOval(500,600,100,40);//FOR EXIT
	//g.drawOval(110,100,520,390);
	

		//g.drawImage(palmdown,360,260);
	g.setBackground(org.newdawn.slick.Color.darkGray);
	Input input=gc.getInput();
	int xpos=Mouse.getX();
	int ypos=Mouse.getY();
	mouse="Mouse position x:"+ xpos +" y:" +ypos;
		
		
		if(true){
			g.drawOval(395,150,50,50);
			g.drawOval(395,300,50,50);
		}	
			
					
	if((xpos>200&&xpos<240)&&(ypos>600&&ypos<640)){
		
		
		
		if(xpos0[j]>200&&xpos0[j]<600){	
			
			
			 
			 
			 try {
					//loop0();
					
					//counter=1;
							
					Thread.sleep(500);
									
				} catch (InterruptedException e) {
							// TODO Auto-generated catch block				
					
					
					e.printStackTrace();
					
					}
							

		}
		else if(xpos0[j]>=800||xpos0[j]<=407){
			
		}
		
		
		
		
		}
	
			
		
	
	
	 if((xpos>500&&xpos<540)&&(ypos>600&&ypos<640)){
		
		if(xpos1[j]>400&&xpos1[j]<600){	
			g.drawImage(fistdown,xpos1[j],ypos1[j]);
			j++;
			try {
				loop1();
				
			delta=1;
				//mike=1;
				
				Thread.sleep(1000);
								
			} catch (InterruptedException e) {
						// TODO Auto-generated catch block				
				
				
				e.printStackTrace();
				
				}
						

			
			System.gc();
			}
		else if(xpos1[j]>=800||xpos1[j]<=407){
					}
		}
	
	
			
	
	
	 if((xpos>600&&xpos<650)&&(ypos>600&&ypos<640)){
		
		
		if(xpos2[j]>400&&xpos2[j]<800){	
			g.drawImage(fistdown,xpos2[j],ypos2[j]);
			j++;
			try {
				loop2();
				
				stan=1;
				//mike=1;
				
				Thread.sleep(1500);
								
			} catch (InterruptedException e) {
						// TODO Auto-generated catch block				
				
				
				e.printStackTrace();
				
				}
						

			
			System.gc();
			}
		else if(xpos2[j]>=800||xpos2[j]<=407){
					}
		}
	
			
	
	
	
	 if((xpos>700&&xpos<750)&&(ypos>600&&ypos<640)){
		
		if(xpos3[j]>400&&xpos3[j]<800){	
			g.drawImage(fistdown,xpos3[j],ypos3[j]);
			j++;
			try {
				loop3();
				
				chali=1;
				//mike=1;
				
				Thread.sleep(1500);
								
			} catch (InterruptedException e) {
						// TODO Auto-generated catch block				
				
				
				e.printStackTrace();
				
				}
						

			
			System.gc();
			}
		else if(xpos3[j]>=800||xpos3[j]<=407){
					}
		}
	
	
			
	
	
	 if((xpos>400&&xpos<440)&&(ypos>550&&ypos<590)){
		
		
		
		if(xpos4[j]>400&&xpos4[j]<800){	
						
			g.drawImage(fistdown,xpos4[j],ypos4[j]);
			j++;
			try {
				loop4();
				
				cambi=1;
				gc.resume();
				Thread.sleep(1500);
								
			} catch (InterruptedException e) {
						// TODO Auto-generated catch block				
				
				
				e.printStackTrace();
				
				}
			System.gc();
			}
		else if(xpos4[j]>=800||xpos4[j]<=407){
					}
		}
	
			
	
	
	 if((xpos>500&&xpos<540)&&(ypos>550&&ypos<590)){
		
		
		if(xpos5[j]>400&&xpos5[j]<800){	
			gc.resume();
			g.drawImage(fistdown,xpos5[j],ypos5[j]);
			j++;
			try {
				loop5();
				
				millij=1;
				
				
				Thread.sleep(1500);
								
			} catch (InterruptedException e) {
						// TODO Auto-generated catch block				
				
				
				e.printStackTrace();
				
				}
						

			
			
			System.gc();
			}
		else if(xpos5[j]>=800||xpos5[j]<=407){
					}
		}
	
					
	
	
	 if((xpos>600&&xpos<650)&&(ypos>550&&ypos<590)){
		
		
		
		
		if(xpos6[j]>400&&xpos6[j]<800){	
			
			g.drawImage(fistdown,xpos6[j],ypos6[j]);
			j++;			
			try {
				loop6();
				
				loyd=1;
				//mike=1;
				
				Thread.sleep(1500);
								
			} catch (InterruptedException e) {
						// TODO Auto-generated catch block				
				
				
				e.printStackTrace();
				
				}
						
	
			System.gc();
			}
		else if(xpos6[j]>=800||xpos6[j]<=407){
					}
		}
	
	
							
	
	
	
	 if((xpos>700&&xpos<750)&&(ypos>550&&ypos<590
			)){
		
		
		
		
		if(xpos7[j]>400&&xpos7[j]<800){	
			g.drawImage(fistdown,xpos7[j],ypos7[j]);
			j++;
			try {
				loop7();
				
				hit=1;
				//mike=1;
				
				Thread.sleep(1500);
								
			} catch (InterruptedException e) {
						// TODO Auto-generated catch block				
				
				
				e.printStackTrace();
				
				}
						

			gc.pause();
			
		//	g.drawImage(pot[0],500,200);
			
						}
		else if(xpos7[j]>=800||xpos7[j]<=407){
					}
		}		
			
	 if((xpos>400&&xpos<450)&&(ypos>445&&ypos<500)){
		
		
		
		if(xpos8[j]>400&&xpos8[j]<800){	
			
			
			try {
				
				Thread.sleep(1500);
			} catch (InterruptedException e) {
								// TODO Auto-generated catch block
								
				
				e.printStackTrace();
				
				}
			System.gc();
			}
		else if(xpos8[j]>=800||xpos8[j]<=407){
					}
		}		
					
					

	
	
	
	 if((xpos>500&&xpos<550)&&(ypos>445&&ypos<500)){
		
		
		if(xpos9[j]>400&&xpos9[j]<800){	
			g.drawImage(fistdown,xpos9[j],ypos9[j]);
			j++;
			try {
				loop9();
				
				terry=1;
				//mike=1;
				
				Thread.sleep(1500);
								
			} catch (InterruptedException e) {
						// TODO Auto-generated catch block				
				
				
				e.printStackTrace();
				
				}
						

			System.gc();
			}
		else if(xpos9[j]>=800||xpos9[j]<=407){
					}
		}	
			
		
	
	
	
	
	
	 if((xpos>600&&xpos<750)&&(ypos>445&&ypos<500)){

			if(xpos10[j]>400&&xpos10[j]<800){	
			
							gc.pause();	
							
			try {
				loop10();
				
				counter=1;
				mike=1;
				g.drawImage(fistdown,xpos10[j],ypos10[j]);
				j++;
//		
				
				Thread.sleep(1500);
								
			} catch (InterruptedException e) {
						// TODO Auto-generated catch block				
				
				
				e.printStackTrace();
				
				}
						
			System.gc();
			}
		else if(xpos10[j]>=800||xpos10[j]<=407){
					}
		}
	
	
	 if((xpos>700&&xpos<750)&&(ypos>450&&ypos<500)){
		//if (input.isKeyDown(Input.KEY_9)){
			if(xpos11[j]>400&&xpos11[j]<800){
				
				g.drawImage(fistdown,xpos11[j],ypos11[j]);
				j++;		
				try {
					loop11();
					
					kuda=1;
					mike=1;
					
					Thread.sleep(1500);
									
				} catch (InterruptedException e) {
							// TODO Auto-generated catch block				
					
					
					e.printStackTrace();
					
					}
							

							
							
				gc.pause();}

						else if(xpos11[j]>=800||xpos11[j]<=407){
					}}
		
	
	
	
	
	
	 if((xpos>700&&xpos<750)&&(ypos>400&&ypos<445)){
		
		
		if(xpos15[j]>400&&xpos15[j]<800){	
			g.drawImage(fistdown,xpos15[j],ypos15[j]);
			j++;
			try {
				loop15();
				
				erau=1;
				//mike=1;
				
				Thread.sleep(1500);
								
			} catch (InterruptedException e) {
						// TODO Auto-generated catch block				
				
				
				e.printStackTrace();
				
				}
						

			
						System.gc();
			}
		else if(xpos15[j]>=800||xpos15[j]<=407){
					}
		}
	

	
	
	
	
	
	
	
	 if((xpos>600&&xpos<650)&&(ypos>400&&ypos<445)){
		
		
		
		if(xpos14[j]>400&&xpos14[j]<800){	
			g.drawImage(fistdown,xpos14[j],ypos14[j]);
			j++;
			try {
				loop14();
				
				oxfod=1;
				mike=1;
				
				Thread.sleep(1500);
								
			} catch (InterruptedException e) {
						// TODO Auto-generated catch block				
				
				
				e.printStackTrace();
				
				}
						
			
			System.gc();
			}
		else if(xpos14[j]>=800||xpos14[j]<=407){
					}
		}


		

	
	 if((xpos>500&&xpos<540)&&(ypos>400&&ypos<440)){
		
		if(xpos13[j]>400&&xpos13[j]<800){
			g.drawImage(fistdown,xpos13[j],ypos13[j]);
			j++;
			try {
				//Sleep(2000);
				loop13();
				nasa=1;
				Thread.sleep(1500);
				
} catch (InterruptedException e) {
		// TODO Auto-generated catch block				


e.printStackTrace();

}
		
			
			System.gc();
			}
		else if(xpos13[j]>=800||xpos13[j]<=407){
			
		}
		}
	
	
	
	
	
 if((xpos>400&&xpos<440)&&(ypos>400&&ypos<445)){
	
if(xpos12[j]>400&&xpos12[j]<800){	
	g.drawImage(fistdown,xpos12[j],ypos12[j]);
	j++;
	try {
		loop12();
		
		tango=1;
		//mike=1;
		
		Thread.sleep(1500);
						
	} catch (InterruptedException e) {
				// TODO Auto-generated catch block				
		
		
		e.printStackTrace();
		
		}
				

	
	System.gc();
}
else if(xpos12[j]>=800||xpos12[j]<=407){
	}}}




	
	
	
	
 
	
	
	
	









public void update(GameContainer gc,StateBasedGame sbg,int delta) throws SlickException{
	
	
	counter+=delta;
	if(delta>=20000){
		counter=0;
		loop13();
	}

	
	
	Input input=gc.getInput();
	int xpos=Mouse.getX();
	int ypos=Mouse.getY();
	mouse="Mouse position x:"+ xpos +" y:" +ypos;
	
	


	

	if((xpos>310 && xpos<370) &&(ypos>150 && ypos<230)){
		
		if (input.isKeyDown(Input.KEY_ENTER)){
		sbg.enterState(1);
		}}
	
	
if((xpos>900 && xpos<950) &&(ypos>130 && ypos<200)){
	if (input.isKeyDown(Input.KEY_ENTER)){
	
		sbg.enterState(4);
		}}

	int speed=1;
float distance=speed*(float)delta/1000;
if(input.isKeyDown(Input.KEY_UP)){
		
	fistdowny-=1;
				
			}
if(input.isKeyDown(Input.KEY_DOWN)){
	
	fistdowny+=1;
				
			}
if(input.isKeyDown(Input.KEY_LEFT)){
	//fistdown.setX( fistdown.getX()+distance);	
	fistdownx-=1;
				
			}
if(input.isKeyDown(Input.KEY_RIGHT)){
	
	fistdownx+=1;
		//xpos1[0]+=50;
		fistdownx++;
			}
	
}

public int getID(){
	return 0;
}


}



		
		
	



