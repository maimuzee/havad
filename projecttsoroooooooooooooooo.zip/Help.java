

package javagame;
import org.lwjgl.input.Mouse;
import org.newdawn.slick.*;
import org.newdawn.slick.state.*;



public class Help extends BasicGameState{
	
	Image gz;
	Image menu;
	
	public String mouse="no input yet?";

	
	public Help(int state){
		
    }

	
	
	
	public void init(GameContainer gc,StateBasedGame sbg) throws SlickException{
		gz=new Image("res/Great-Zimbabwe-BW-650px.jpg");
		menu=new Image("res/menu_pull_up.png");
	}



	public void render(GameContainer gc,StateBasedGame sbg,Graphics g) throws SlickException{
		
		//Input input=gc.getInput();
		int xpos=Mouse.getX();
		int ypos=Mouse.getY();
		mouse="Mouse position x:"+ xpos +" y:" +ypos;
		
		gz.draw(0,0,2.6f);
		g.drawImage(menu,600,600);
		g.drawString("\tVERSION ZERO ...TSOROO......@HIT@ZIM\n THE GAME IS PLAYED AS FOLLOWS::\nA PLAYER IS GIVEN A BANK WHICH HAS A CIRCLE ARROUND IT.\nA PLAYER AT THE LOWER PART OF THE GAME STARTS FIRST.\nA PLAYER CHOOSES A POT TO START WITH AND THE DIRECTION OF MOVEMENT IS ONLY\n IA A COUNTERCLOCKWISE DIRECTION.\nTHE GAME ENDS WHEN ALL THE STONES IN ALL THE POTS ARE IN THE BANK OF EACH PLAYER.\n ",205,200);
}
	public void update(GameContainer gc,StateBasedGame sbg,int delta) throws SlickException{
		Input input=gc.getInput();
		int xpos=Mouse.getX();
		int ypos=Mouse.getY();
		mouse="Mouse position x:"+ xpos +" y:" +ypos;
			
if((xpos>580 && xpos<680) &&(ypos>100 && ypos<200)){
			
			if (input.isKeyDown(Input.KEY_ENTER)){
			sbg.enterState(1);
			}}
			




}
	public int getID(){
		return 3;
	}}	

